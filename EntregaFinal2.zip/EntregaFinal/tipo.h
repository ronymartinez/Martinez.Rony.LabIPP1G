#ifndef TIPO_H_INCLUDED
#define TIPO_H_INCLUDED

typedef struct
{
    int idTipo; // comienza en 5,000
    char descripcion[20];
} eTipo;

#endif // TIPO_H_INCLUDED

int cargarTipo (char *nombreTipo, eTipo *tipo, int tamTipo, int idTipo);
int listarTipos(eTipo *tipo, int tamTipo);


